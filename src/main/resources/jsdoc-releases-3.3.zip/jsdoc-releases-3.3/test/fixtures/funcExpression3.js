ns = {
    /** @class */
    Foo: function Bar(a) {
        /** document me */
        var var1 = 1;
        /** document me */
        this.member1 = 2;
    }
};