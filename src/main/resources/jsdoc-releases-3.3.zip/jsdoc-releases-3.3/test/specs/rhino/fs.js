'use strict';

xdescribe('rhino/fs', function() {
    // TODO
});
