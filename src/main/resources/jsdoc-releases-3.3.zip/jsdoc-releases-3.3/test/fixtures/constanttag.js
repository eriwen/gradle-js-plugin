/** @constant */
var FOO = 1;

/** @const BAR */

/** @const {string} BAZ */

/** @const {number} */
var QUX = 0;

/** @const {Object} SOCKET */
var mySocket;

/** @const ROCKET */
var myRocket;
