var myObject = {
    foo: 1,
    bar: 2
};
