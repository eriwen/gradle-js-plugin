
exports.puts = function(str) {
    print(String(str));
};
