/** @namespace */
var constructor = {
    /** document me */
    toString: function() {}
};

/** @namespace */
var prototype = {
    /** document me */
    valueOf: function() {}
};

/** document me */
var hasOwnProperty = Object.prototype.hasOwnProperty;
