'use strict';

module.exports = require('buffer-browserify');
