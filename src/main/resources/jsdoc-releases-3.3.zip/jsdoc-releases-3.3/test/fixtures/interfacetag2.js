/**
 * Virtual doclet for an interface.
 *
 * @interface VirtualInterface
 */
