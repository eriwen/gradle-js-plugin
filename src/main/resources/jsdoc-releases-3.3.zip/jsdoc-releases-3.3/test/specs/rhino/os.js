'use strict';

xdescribe('rhino/os', function() {
    // TODO
});
