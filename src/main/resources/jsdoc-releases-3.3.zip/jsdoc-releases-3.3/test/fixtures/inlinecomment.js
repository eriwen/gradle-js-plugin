/** Inline Comment 1 */ this.test = function(){}
/** Inline Comment 2 */ this.test2 = function(){};
