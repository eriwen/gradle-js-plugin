'use strict';

xdescribe('jsdoc/borrow', function() {
    // TODO
});
