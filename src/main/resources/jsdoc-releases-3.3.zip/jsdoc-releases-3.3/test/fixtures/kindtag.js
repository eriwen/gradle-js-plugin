/** @kind function */
var x;
