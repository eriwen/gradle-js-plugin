var ns = {
    foo: function(/** Number */ a, /** Number */ b) {}
};
